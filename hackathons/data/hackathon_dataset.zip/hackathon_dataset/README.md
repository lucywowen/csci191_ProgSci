# Hackathon Dataset: Multiple Files & Conditionals (Synthetic)

Welcome! This dataset is designed to practice:
1) Loading many monthly CSVs
2) Tracking file provenance (source filename)
3) Handling schema drift and union-concatenation
4) Writing robust conditionals for filtering/validation
5) Simple log parsing

## Folder Structure
- `data/` — 12 files: `measurements_2024-01.csv` ... `2024-12.csv`
- `logs/` — 9 files: `2024-01.csv` ... `2024-09.csv`

## Data Schema
**Common columns in `data/measurements_YYYY-MM.csv`**
- `date` (string) — ISO-ish dates; one known invalid value is included (e.g., `2024-02-30`)
- `sensor_id` (string) — sometimes missing/blank; in **July** the column is named `sensorID`
- `temp_c` (float) — temperatures with seasonal variation; rare out-of-range values (< -50 or > 60)
- `status` (string/NaN) — values like OK/WARN/ERROR in mixed cases and with occasional surrounding spaces
- `notes` (string, optional) — present in Mar/Jun/Sep/Dec
- other occasional columns: April uses `tempC` (instead of `temp_c`), October has `misc_flag`

**`logs/YYYY-MM.csv`**
- `timestamp` (string) — ISO-like timestamp
- `status` (string) — typically "ok", "OK", "error", "warn" with some trailing whitespace
- `message` (string)
- `detail` (string, optional in a few months)

## Suggested Tasks
1. **Load & Combine (data/):**
   - Read all `measurements_2024-??.csv`
   - Add a `source_file` column with the filename for each row
   - Union-concatenate (allow missing columns; do **not** fail on schema differences)

2. **Clean & Filter:**
   - Normalize `status` (strip spaces, case-fold to upper/lower)
   - Drop rows where `status` is missing/empty or equals "error" (case-insensitive)
   - Flag suspicious temperatures: `temp_c < -30` or `temp_c > 50`

3. **Validate (vectorized conditionals):**
   - `date` parseable to datetime
   - non-empty `sensor_id`
   - `temp_c` between -50 and 60 (inclusive)
   - `status` in `{'OK','WARN','ERROR'}` case-insensitive
   - Produce a boolean `is_valid` column

4. **Logs Parsing:**
   - `glob('logs/2024-0?.csv')` to load months 1–9
   - Filter to rows where `status.lower().strip() == 'ok'`
   - Compute per-month counts

## Notes
- A few duplicates exist by design.
- Mixed casing and stray spaces in `status` are intentional.
- Column names vary in a couple of months (`tempC`, `sensorID`) — handle gracefully.

Good luck and have fun!
